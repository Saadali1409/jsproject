let saad =  { 
    name:"saad",
    age:21,
    greet:"kya hall chall hain app logon ke ",

    greeting: function () {

        console.log(`this is ${this.name} i am  ${this.age}  years old ${this.greet}`)
    }
}  

saad.greeting()