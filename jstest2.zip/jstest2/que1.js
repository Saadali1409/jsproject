function saad() {
    let num = parseInt(prompt("Enter a number:"));
    if (num > 0) {
        alert("Positive Number");
    } else if (num < 0) {
        alert("Negative Number");
    } else {
        alert("Zero");
    }
}